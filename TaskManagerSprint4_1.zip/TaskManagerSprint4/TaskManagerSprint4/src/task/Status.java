package task;

public enum Status {
    NEW,
    IN_PROGRESS,
    DONE
}