public class Main {

    public static void main(String[] args) {

        TaskManager taskManager = new TaskManager();

        Task readNietzsche = new Task("Прочитать книгу Ницше ", "На немецком языке");
        Task readNietzscheCreated = taskManager.addTask(readNietzsche);
        System.out.println(readNietzscheCreated);

        Task readNietzscheToUpdate = new Task(readNietzsche.getId(), "Пора приниматься за первый том Ницше", "Для начала на русском языке",
                Status.IN_PROGRESS);
        Task readNietzscheUpdated = taskManager.updateTask(readNietzscheToUpdate);
        System.out.println(readNietzscheUpdated);


        Epic yandexEducation = new Epic("Сдать все задания первого модуля", "Нужно успеть до вечера понедельника");
        taskManager.addEpic(yandexEducation);
        System.out.println(yandexEducation);
        Subtask yandexEducationSubtask1 = new Subtask("Сдать 4й спринт", "Написать трекер задач",
                yandexEducation.getId());
        Subtask yandexEducationSubtask2 = new Subtask("Изучить теорию 5го спринта", "Это было непросто, особенно полиморфизм",
                yandexEducation.getId());
        taskManager.addSubtask(yandexEducationSubtask1);
        taskManager.addSubtask(yandexEducationSubtask2);
        System.out.println(yandexEducationSubtask1);
        yandexEducationSubtask2.setStatus(Status.DONE);
        taskManager.updateSubtask(yandexEducationSubtask2);
        System.out.println(yandexEducationSubtask2);
    }
}